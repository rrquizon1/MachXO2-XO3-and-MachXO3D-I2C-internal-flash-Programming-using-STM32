/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "data.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
/* USER CODE BEGIN PFP */
void device_id(uint8_t addr);
void isc_enable_sram(uint8_t addr);
void isc_erase_sram(uint8_t addr);
void sr_read(uint8_t addr);
void isc_enable_flash_XO2_XO3(uint8_t addr);
void isc_erase_flash_XO2_XO3(uint8_t addr);
void lsc_init_address_XO2_XO3(uint8_t addr);
void flash_program(uint8_t addr,const unsigned char *bitstream,const int bit_len);
void flash_verify(uint8_t addr,const unsigned char *bitstream,const int bit_len);
void program_done(uint8_t addr);
void isc_disable(uint8_t addr);
void program_XO2_XO3(uint8_t addr, const unsigned char *bitstream, const int bitstream_len);
void program_XO3D(uint8_t addr, const unsigned char *bitstream, const int bitstream_len,int CFG);
void isc_erase_flash_XO3D(uint8_t addr, int CFG);
void lsc_init_address_XO3D(uint8_t addr,int CFG);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */
  #define I2C_ADDRESS_XO3D  0x08  // Slave address
  #define I2C_ADDRESS_XO3  0x40  // Slave address

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

	  device_id(I2C_ADDRESS_XO3D);//device ID read
	  HAL_Delay(1);
	  device_id(I2C_ADDRESS_XO3);//device ID read
	  HAL_Delay(1);
	  int CFG=0;
	  program_XO2_XO3(I2C_ADDRESS_XO3,g_pucDataArray_XO3,g_int_XO3);
	  program_XO3D(I2C_ADDRESS_XO3D,g_pucDataArray_XO3D,g_int_XO3D,CFG);

	  exit(0);


    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

void program_XO3D(uint8_t addr, const unsigned char *bitstream,  const int bitstream_len,int CFG){

	  printf("==================================================================\n");
	  printf("Programming MachXO3D internal flash at address 0x%02x\n",addr);
	  printf("==================================================================\n");
	  device_id(addr);//device ID read
	  isc_enable_sram(addr);//Configuration Mode:SRAM
	  isc_erase_sram(addr);// Erase SRAM
	  sr_read(addr);//Read Status Register
	  isc_enable_flash_XO2_XO3(addr);//Configuration Mode: Internal FLash
	  isc_erase_flash_XO3D(addr,CFG);// Erase internal flash
	  sr_read(addr);// Read Status Register
	  lsc_init_address_XO3D(addr,CFG);// Initialize Address: CFGX
	  flash_program(addr,bitstream,bitstream_len);// Program internal flash
	  lsc_init_address_XO3D(addr,CFG);//Initialize Address: CFGX
	  flash_verify(addr,bitstream,bitstream_len);// Verify internal flash
	  lsc_init_address_XO3D(addr,CFG);//Initialize Address: CFGX
	  program_done(addr);//Program DONE
	  sr_read(addr);//Read Status Register
	  isc_disable(addr);//Exits Programming Mode

}

void isc_erase_flash_XO3D(uint8_t addr, int CFG){
	 printf("Erasing Internal Flash.....\n");
	 uint8_t txData[4] = {0x0E, 0x00, 0x01, 0x00};
	 if (CFG==0){
		 txData[2]=0x01;
	 }

	 else{
		 txData[2]=0x02;

	 }
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(5000);
	 printf("Internal Flash Erased!\n");


}

void program_XO2_XO3(uint8_t addr, const unsigned char *bitstream,const int bitstream_len){

	  printf("==================================================================\n");
	  printf("Programming MachXO2/MachXO3 internal flash at address 0x%02x \n",addr);
	  printf("==================================================================\n");
	  device_id(addr);//Device ID read
	  isc_enable_sram(addr);//Configuration Mode:SRAM
	  isc_erase_sram(addr);//Erase SRAM
	  sr_read(addr);// Read status Register
	  isc_enable_flash_XO2_XO3(addr);// Configuration mode: Flash
	  isc_erase_flash_XO2_XO3(addr);// Erase Flash
	  sr_read(addr);// Status Register Read
	  lsc_init_address_XO2_XO3(addr);//Init Address CFG
	  flash_program(addr,bitstream,bitstream_len);//Internal Flash Programming
	  lsc_init_address_XO2_XO3(addr);//Initial Address
	  flash_verify(addr,bitstream,bitstream_len);//Verify Internal Flash
	  program_done(addr);//Program DONE bit
	  sr_read(addr);//Read Status Register
	  isc_disable(addr);//Exit Programming Mode

}
void isc_disable(uint8_t addr){

	 uint8_t txData[4] = {0x26, 0x00, 0x00, 0x00};
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(1);
	 printf("Device Exits Programming Mode!\n");




}
void program_done(uint8_t addr){
	 uint8_t txData[4] = {0x5E, 0x00, 0x00, 0x00};
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(1);
	 printf("DONE bit programmed!\n");



}

void flash_verify(uint8_t addr,const unsigned char *bitstream,const int bit_len){
		int num_chunks= ((bit_len + 16 - 1) / 16);
	    //printf("Num Chunks: %d \n",num_chunks);
	    unsigned char txData[4]={0x73,0x00,0x00,0x00};
	    unsigned char  rxData[16];
	     printf("Verifying internal flash..\n");
	    for(int k=0;k<num_chunks;k++){
	        //i2c_write_and_read(lsc_read_incr,4,read_data,16); //Read Status Register
	  	  HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_FRAME);
	  	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	  	  HAL_I2C_Master_Seq_Receive_IT(&hi2c1, addr << 1, rxData, 16, I2C_LAST_FRAME);
	  	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready

	    if (memcmp( rxData, &bitstream[k*16], 16) == 0) {

	    } else {
	        printf("Verify Fail\n");
	        exit(0);
	    }

	    HAL_Delay(10);
	    }
	    printf("Verify Successful!\n");


}

void flash_program(uint8_t addr, const unsigned char *bitstream, const int bit_len){

   int num_chunks= ((bit_len + 16 - 1) / 16);
   // printf("Num Chunks: %d \n",num_chunks);
  uint8_t txData[4]={0x70,0x00,0x00,0x00};
   printf("Programming internal flash..\n");
   for(int k=0;k<num_chunks;k++){
	   HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_FRAME);
	   while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	   HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, (uint8_t *) &bitstream[k*16], 16, I2C_LAST_FRAME);
	   while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
    //i2c_write_long(lsc_prog_incr,4,&g_pucDataArray[k*16],16);
	HAL_Delay(2);
  }
   printf("Finished programming internal flash\n");


}
void lsc_init_address_XO2_XO3(uint8_t addr){

	 uint8_t txData[4] = {0x46, 0x04, 0x00, 0x00};
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(1);
	 printf("Address Initialized at internal flash\n");



}


void lsc_init_address_XO3D(uint8_t addr,int CFG){

	 uint8_t txData[4] = {0x46, 0x00, 0x01, 0x00};
	 if (CFG==0){
		 txData[2]=0x01;
		 printf("Init Address at CFG0\n");
	 }

	 else if (CFG==1){
		 txData[2]=0x02;
		 printf("Init Address at CFG1\n");
	 }

	 else if (CFG==3){
		 txData[2] =0x00;
		 txData[1] =0x04;
		 printf("Init Address at feature row\n");

	 }

	 else{

		 printf("Not a Valid sector\n");
	 }
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(1);
	 printf("Address Initialized at internal flash\n");



}
void isc_erase_flash_XO2_XO3(uint8_t addr){
	 printf("Erasing Internal Flash.....\n");
	 uint8_t txData[4] = {0x0E, 0x04, 0x00, 0x00};
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(5000);
	 printf("Internal Flash Erased!\n");


}
void isc_enable_flash_XO2_XO3(uint8_t addr){
	 uint8_t txData[4] = {0xC6, 0x08, 0x00, 0x00};
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(1);
	 printf("Device Enters Config Mode:Flash\n");



}
void sr_read(uint8_t addr){
	  uint8_t txData[4] = {0x3C, 0x00, 0x00, 0x00};
	  uint8_t rxData[4];
	  HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_FRAME);
	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	  HAL_I2C_Master_Seq_Receive_IT(&hi2c1, addr << 1, rxData, 4, I2C_LAST_FRAME);
	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	  printf("Status Register Read:\n");
	  for(uint8_t i=0;i<4;i++){
	  	  	 printf("0x%02X\n",rxData[i]);

	    }


}
void  device_id(uint8_t addr){
	  uint8_t txData[4] = {0xE0, 0x00, 0x00, 0x00};
	  uint8_t rxData[4];
	  HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_FRAME);
	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	  HAL_I2C_Master_Seq_Receive_IT(&hi2c1, addr << 1, rxData, 4, I2C_LAST_FRAME);
	  while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	  printf("Device ID Read:\n");
	  for(uint8_t i=0;i<4;i++){
	  	  	 printf("0x%02X\n",rxData[i]);

	    }

}

void isc_enable_sram(uint8_t addr){
	 uint8_t txData[4] = {0xC6, 0x00, 0x00, 0x00};
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(1);
	 printf("Device Enters Config Mode:SRAM\n");

}


void isc_erase_sram(uint8_t addr){
	 uint8_t txData[4] = {0x0E, 0x01, 0x00, 0x00};
	 HAL_I2C_Master_Seq_Transmit_IT(&hi2c1, addr << 1, txData, 4, I2C_FIRST_AND_LAST_FRAME);
	 while (HAL_I2C_GetState(&hi2c1) != HAL_I2C_STATE_READY);//wait for i2c to be ready
	 HAL_Delay(1);
	 printf("SRAM Erased\n");
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(CS_I2C_SPI_GPIO_Port, CS_I2C_SPI_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(OTG_FS_PowerSwitchOn_GPIO_Port, OTG_FS_PowerSwitchOn_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, LD4_Pin|LD3_Pin|LD5_Pin|LD6_Pin
                          |Audio_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : PE2 PE8 */
  GPIO_InitStruct.Pin = GPIO_PIN_2|GPIO_PIN_8;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : CS_I2C_SPI_Pin */
  GPIO_InitStruct.Pin = CS_I2C_SPI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CS_I2C_SPI_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PE4 PE5 MEMS_INT2_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|MEMS_INT2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : OTG_FS_PowerSwitchOn_Pin */
  GPIO_InitStruct.Pin = OTG_FS_PowerSwitchOn_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(OTG_FS_PowerSwitchOn_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PDM_OUT_Pin */
  GPIO_InitStruct.Pin = PDM_OUT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
  HAL_GPIO_Init(PDM_OUT_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : PA0 */
  GPIO_InitStruct.Pin = GPIO_PIN_0;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : I2S3_WS_Pin */
  GPIO_InitStruct.Pin = I2S3_WS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF6_SPI3;
  HAL_GPIO_Init(I2S3_WS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : SPI1_SCK_Pin SPI1_MISO_Pin SPI1_MOSI_Pin */
  GPIO_InitStruct.Pin = SPI1_SCK_Pin|SPI1_MISO_Pin|SPI1_MOSI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : CLK_IN_Pin PB12 */
  GPIO_InitStruct.Pin = CLK_IN_Pin|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LD4_Pin LD3_Pin LD5_Pin LD6_Pin
                           Audio_RST_Pin */
  GPIO_InitStruct.Pin = LD4_Pin|LD3_Pin|LD5_Pin|LD6_Pin
                          |Audio_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : I2S3_MCK_Pin I2S3_SCK_Pin I2S3_SD_Pin */
  GPIO_InitStruct.Pin = I2S3_MCK_Pin|I2S3_SCK_Pin|I2S3_SD_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF6_SPI3;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : VBUS_FS_Pin */
  GPIO_InitStruct.Pin = VBUS_FS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(VBUS_FS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : OTG_FS_ID_Pin OTG_FS_DM_Pin OTG_FS_DP_Pin */
  GPIO_InitStruct.Pin = OTG_FS_ID_Pin|OTG_FS_DM_Pin|OTG_FS_DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_OTG_FS;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : OTG_FS_OverCurrent_Pin */
  GPIO_InitStruct.Pin = OTG_FS_OverCurrent_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(OTG_FS_OverCurrent_GPIO_Port, &GPIO_InitStruct);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
